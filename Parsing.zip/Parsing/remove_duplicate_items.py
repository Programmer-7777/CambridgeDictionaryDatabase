import numpy as np
f = open("noun_lemma.txt", "r")
ff = open("noun", "w")
string = f.read()
listt = string.splitlines()
print(len(listt))
sett = set(listt)
print(len(sett))
arr = np.array(sett)
for word in sett:
    ff.write(word + "\n")
    
f.close()
ff.close()
    


