from bs4 import BeautifulSoup
import requests
f = open("adjective", "w")

url = 'https://en.wiktionary.org/w/index.php?title=Category:English_adjectives&pagefrom=ABAISSE%0Aabaiss%C3%A9#mw-pages'

i = 0 
while url != 'https://en.wiktionary.org/w/index.php?title=Category:English_adjectives&pagefrom=ACCOMPLISHABLE%0Aaccomplishable#mw-pages':
    r = requests.get(url)
    html_doc = r.text
    soup = BeautifulSoup(html_doc, 'html.parser')
    divclass = soup.select(".mw-category")[1]
    lis = divclass.contents
    # divlink = soup.select("#mw-pages")
    # print((divlink[0].contents)[5])
    
    for div in lis:
        li = div.contents[2].contents
        for z in range(0, len(li), 2):
            f.write(li[z].contents[0].contents[0] + "\n")
        
                    


    link = soup.select("#mw-pages")[0].contents[7]
    url = 'https://en.wiktionary.org' + str(link['href'])

    
    i = i+1
    print(i)

f.close()